l=100
while ((l>0))
do
	sleep 2
	echo $l
	((l--))
done	
