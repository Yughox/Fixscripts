#!/bin/bash

for number in {0..9}
do 
	echo "Number: $number"
done
