#!/bin/bash

echo "enter a word"
read string
	
	n="${#string}"

echo $n
