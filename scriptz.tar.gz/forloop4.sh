CITIES=("LosAngeles" "Chicago" "Washington" "NewYork" "NewOrleans")

for city in "${CITIES[@]}";
do 
	echo "City: $city"
done
