echo "counting down"
for ((a=25;a>=0;a--))
do
	sleep 2
	echo $a
done
