#!/bin/bash

<<mc 
a= date
echo "Good Morning"
echo "Welcome to Ubuntu"
echo "today is $a"
mc

name=yugho
cpy=Amazon

echo "Welcome Mr $name"
echo "What would you request from $cpy today"
echo "Thanks"
#comment one
